#!/usr/bin/env python
#=======================================================================
# Copyright (C) 2013 William Hallahan
#
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation
# files (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
# WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
# OTHER DEALINGS IN THE SOFTWARE.
#=======================================================================

import time
from program_properties import ProgramProperties
from carginfo import CArgInfo
from carginfo import has_non_bool_switch_argument
from carginfo import get_number_of_switch_arguments
from carginfo import has_switch_argument
from carginfo import get_number_of_positional_arguments
from carginfo import has_positional_argument
from carginfo import has_int_parameter
from carginfo import has_float_parameter

def _get_program_argument_help_text(arg_info_list, required_positional_arg_count):
    arg_text = ''
    i = 0
    for arg_info in arg_info_list:
        if arg_info.is_positional():
            arg_text = '{0} <{1}>'.format(arg_text, arg_info.get_name())
    for arg_info in arg_info_list:
        if arg_info.has_switch():
            short_switch_name, long_switch_name = get_switch_names(arg_info.get_switch_name_list())
            if short_switch_name:
                short_switch_name = '-{0}'.format(short_switch_name)
            if long_switch_name:
                if short_switch_name:
                    long_switch_name = ', --{0}'.format(long_switch_name)
                else:
                    long_switch_name = '--{0}'.format(long_switch_name)
            if arg_info.get_type() == 'BOOL':
                arg_text = '{0} [{1}{2}]'.format(arg_text,
                                                 short_switch_name,
                                                 long_switch_name)
            else:
                arg_text = '{0} [{1}{2} {3}]'.format(arg_text,
                                                     short_switch_name,
                                                     long_switch_name,
                                                     arg_info.get_name())
    return arg_text

def _get_year():
    """ Returns a string that contains the year. """
    now = time.ctime()
    now_list = now.split()
    year = now_list[4]
    return year

def _get_function_declaration_string(return_type, function_name, arg_info_list):
    """ Writes a function declaration, such as:
        'void execute<Name>(TCHAR * input_file_name)'
    """
    function_declaration_text = '{0} {1}('.format(return_type, function_name)
    number_of_params = len(arg_info_list)
    for i in xrange(0, number_of_params):
        arg = arg_info_list[i]
        function_declaration_text = '{0}{1} {2}'.format(function_declaration_text, arg.get_type(), arg.get_name())
        if i != (number_of_params - 1):
            function_declaration_text = '{0}, '.format(function_declaration_text)
    function_declaration_text = '{0})'.format(function_declaration_text)
    return function_declaration_text

def _get_function_call_string(return_type, function_name, arg_info_list):
    """ Writes a function call, such as:
        'execute<Name>(input_file_name)'
    """
    function_call_text = '{0} {1}('.format(return_type, function_name)
    number_of_params = len(arg_info_list)
    for i in xrange(0, number_of_params):
        arg = arg_info_list[i]
        function_call_text = '{0}{1}'.format(function_call_text, arg.get_name())
        if i != (number_of_params - 1):
            function_call_text = '{0}, '.format(function_call_text)
    function_call_text = '{0});'.format(function_call_text)
    return function_call_text

def remove_leading_characters(name, character):
    while name.startswith(character):
        name = name[1:]
    return name

def get_opposite_bool_text(bool_text):
    """ This method returns 'FALSE' if 'TRUE' is passed
        and 'TRUE' if 'FALSE is passed. """
    value = ''
    if bool_text == 'FALSE':
        value = 'TRUE'
    elif bool_text == 'TRUE':
        value = 'FALSE'
    elif bool_text == 'false':
        value = 'true'
    elif bool_text == 'true':
        value = 'false'
    return value

def convert_to_cpp_type(prog_properties, type_name):
    """ If C++, converts 'BOOL' to 'bool' """
    if prog_properties.is_cpp_program() and type_name == 'BOOL':
        type_name = type_name.lower()
    return type_name

def convert_to_cpp_value(prog_properties, value_name):
    """ If C++, converts 'FALSE" or 'TRUE' to
        'false' or 'true' respectively.
    """
    if (prog_properties.is_cpp_program()
        and (value_name == 'FALSE' or value_name == 'TRUE')):
        value_name = value_name.lower()
    return value_name

def get_switch_names(switch_name_list):
    short_switch_name = ''
    long_switch_name = ''
    for switch_name in switch_name_list:
        switch_name = remove_leading_characters(switch_name, '-')
        if len(switch_name) == 1:
            short_switch_name = switch_name
        else:
            long_switch_name = switch_name
    return short_switch_name, long_switch_name
    
def write_parsing_variable_declarations(c_file,
                                        arg_info_list,
                                        positional_argument_count,
                                        leading_space_count):
    leading_whitespace = ''.join(' ' for i in xrange(0, leading_space_count))
    # Code for the -h and --help switches is always generated,
    # so the following test was removed.
    #if total_argument_count > 0:
    c_file.write('{0}int arg_index = 0;\n'.format(leading_whitespace))
    if positional_argument_count > 0:
        c_file.write('{0}int positional_arg_index = 0;\n'.format(leading_whitespace))
    c_file.write('{0}int arg_result = 0;\n'.format(leading_whitespace))
    if has_int_parameter(arg_info_list) or has_float_parameter(arg_info_list):
         c_file.write('{0}TCHAR * stop_ptr = NULL;\n'.format(leading_whitespace))
    c_file.write('\n')

def declare_argument_option_array(c_file, arg_info_list, leading_space_count):
    leading_whitespace = ''.join(' ' for i in xrange(0, leading_space_count))
    # Declare a structure for optional switch arguments.
    # Code for the -h and --help switches is always generated,
    # so the following test was removed.
    #if optional_argument_count > 0:
    # The optional switch argument structure is of the form:
    # static const ArgOption_t argument_option_array[] =
    # {
    #     { _T("name"), OPTION_REQUIRES_PARAMETER, _T('n') },
    #     { _T("gender"), OPTION_REQUIRES_PARAMETER, _T('g'), },
    #     { NULL, 0, 0 }
    # };
    c_file.write('{0}static const ArgOption_t argument_option_array[] =\n{1}{2}\n'.format(leading_whitespace,
                                                                                          leading_whitespace,
                                                                                          '{'))
    out_of_band_count = 0
    for arg_info in arg_info_list:
        if arg_info.has_switch():
            short_switch_name, long_switch_name = get_switch_names(arg_info.get_switch_name_list())
            if not long_switch_name:
                long_switch_name = ''
            option_param_type = 'OPTION_REQUIRES_PARAMETER'
            if arg_info.get_type() == 'BOOL':
                option_param_type = 'OPTION_NO_PARAMETER'
            if short_switch_name:
                short_switch_name = "_T('{0}')".format(short_switch_name)
            else:
                short_switch_name = 'OPTINT{0}'.format(out_of_band_count)
                out_of_band_count += 1
            if long_switch_name:
                long_switch_name = '_T("{0}")'.format(long_switch_name)
            else:
                long_switch_name = 'NULL'
            c_file.write('    {0}{1} {2}, {3}, {4}, {5},\n'.format(leading_whitespace,
                                                                   '{',
                                                                   short_switch_name,
                                                                   long_switch_name,
                                                                   option_param_type,
                                                                   '}'))
    # Always add an entry for program help.
    c_file.write("""    {0}{1} _T('h'), _T("help"), OPTION_NO_PARAMETER {2},\n""".format(leading_whitespace,
                                                                                         '{',
                                                                                         '}'))
    c_file.write("    {0}{1} 0, NULL, OPTION_NO_PARAMETER {2}\n".format(leading_whitespace,
                                                                                '{',
                                                                                '}'))
    c_file.write('{0}{1};\n\n'.format(leading_whitespace, '}'))

def write_conversion_validation_code(outfile, prog_properties):
    outfile.write('                    if (_tcslen(stop_ptr) > 0)\n')
    outfile.write('                    {\n')
    if prog_properties.is_c_program():
        outfile.write('                        _tprintf(_T("Error in argument %s.{0}"), argv[arg_index]);\n'.format(r'\n'))
    else:
        outfile.write('                        STD_COUT << _T("Error in argument %s.") << argv[arg_index] << _T("{0}");\n'.format(r'\n'))
    outfile.write('                        status = -1;\n')
    outfile.write('                    }\n')

def write_c_cpp_program(c_file,
                        prog_properties,
                        platform_header_file_name,
                        arg_info_list,
                        required_positional_arg_count):
    """ Write the main function and helper functions for a c program. """
    base_program_name = prog_properties.get_base_name()
    c_file_name = prog_properties.get_file_name()
    optional_argument_count = get_number_of_switch_arguments(arg_info_list)
    positional_argument_count = get_number_of_positional_arguments(arg_info_list)
    total_argument_count = optional_argument_count + positional_argument_count
    # Get comment style strings.
    comment_start = r'/*'
    comment_continue = ' *'
    comment_end = r' */'
    if prog_properties.is_cpp_program():
        comment_start = r'//'
        comment_continue = r'//'
        comment_end = ''
    c_file.write('{0} Program: {1}{2}\n\n'.format(comment_start,
                                                  c_file_name,
                                                  comment_end))
    # Write include file declarations.
    if prog_properties.is_cpp_program():
        c_file.write('#include <iostream>\n')
        c_file.write('#include <cstring>\n')  
    else:
        c_file.write('#include <stdio.h>\n')
        c_file.write('#include <string.h>\n')  
    if has_int_parameter(arg_info_list) or has_float_parameter(arg_info_list):
        c_file.write('#include <stdlib.h>\n')
    c_file.write('#ifdef __linux__\n')
    c_file.write('#include <unistd.h>\n')
    c_file.write('#endif\n')
    c_file.write('#include "get_arguments.h"\n')
    c_file.write('#include "{0}"\n\n'.format(platform_header_file_name))
    # If there are only option arguments with only a long switch name, create
    # an enum with out-of-band option character values.
    need_out_of_band_enum = False
    for arg_info in arg_info_list:
            if arg_info.has_switch():
                short_switch_name, long_switch_name = get_switch_names(arg_info.get_switch_name_list())
                if long_switch_name and not short_switch_name:
                    need_out_of_band_enum = True
                    break
    if need_out_of_band_enum:
        c_file.write('{0} Define the option character values for optional arguments\n'.format(comment_start))
        c_file.write('{0} that only have a long option name.{1}\n'.format(comment_continue, comment_end))
        c_file.write('typedef enum\n')
        c_file.write('{\n')
        out_of_band_count = 0
        for arg_info in arg_info_list:
            if arg_info.has_switch():
                short_switch_name, long_switch_name = get_switch_names(arg_info.get_switch_name_list())
                if long_switch_name and not short_switch_name:
                    if out_of_band_count == 0:
                        c_file.write('    OPTINT0 = 1114112')
                    else:
                        c_file.write(',\n    OPTINT{0}'.format(out_of_band_count))
                    out_of_band_count += 1
        c_file.write('\n} OptChar_t;\n\n')
    if total_argument_count > 0:
        # Write a structure to store the program arguments.
        # typedef struct
        # {
        #     TCHAR * name;
        #     TCHAR * gender;
        #     TCHAR * age;
        # } ProgramArgument_T;
        c_file.write('{0} Structure type used for program arguments.{1}\n'.format(comment_start, comment_end))
        c_file.write('typedef struct\n{\n')
        for arg_info in arg_info_list:
            arg_type = convert_to_cpp_type(prog_properties, arg_info.get_type())
            c_file.write('    {0} {1};\n'.format(arg_type,
                                                 arg_info.get_name()))
        c_file.write('} ProgramArgument_T;\n\n')
    # Write forward declarations.
    c_file.write('{0} Forward declarations.{1}\n'.format(comment_start, comment_end))
    if total_argument_count > 0:
        # Declare the execute<Name> function forward declaration.
        primary_function_name = 'execute{0}'.format(base_program_name)
        primary_function_argument = ''
        primary_function_arg_info = CArgInfo()
        primary_function_arg_info_list = []
        if total_argument_count > 0:
            primary_function_arg_info.set_type('ProgramArgument_T *')
            primary_function_arg_info.set_name('program_args_ptr')
            primary_function_arg_info_list = [primary_function_arg_info]
        #primary_function_argument = 'ProgramArgument_T * program_args_ptr'
        #primary_function_declaration_text = 'int {0}({1})'.format(primary_function_name,
        #                                                          primary_function_argument)
        primary_function_declaration_text = _get_function_declaration_string('int',
                                                                         primary_function_name,
                                                                         primary_function_arg_info_list)
        c_file.write('{0};\n'.format(primary_function_declaration_text))
    # Declare the displayUsage function forward declaration.
    c_file.write('void displayUsage();\n\n')
    #------------------------------------------------------------------
    # Write the main function.
    #------------------------------------------------------------------
    c_file.write('{0} Start of main program.{1}\n'.format(comment_start, comment_end))
    c_file.write('int _tmain(int argc, TCHAR* argv[])\n')
    c_file.write('{\n')
    c_file.write('    int status = 0;\n')
    if prog_properties.is_c_program():
        # Declare parsing variables.
        leading_space_count = 4
        write_parsing_variable_declarations(c_file,
                                            arg_info_list,
                                            positional_argument_count,
                                            leading_space_count)
        # If there are any arguments, declare a structure instance to store the argument values.
        if total_argument_count > 0:
            c_file.write('    ProgramArgument_T program_args;\n\n')
        # Declare the argument options array.
        # static const ArgOption_t argument_option_array[] = <followed by declarations>
        leading_space_count = 4
        declare_argument_option_array(c_file, arg_info_list, leading_space_count)
    if prog_properties.is_cpp_program():
        # Add code for printing using C++ with Unicode on Windows(TM).
        c_file.write('\n    // Set the print mode for Unicode builds on Windows(TM).\n')
        c_file.write('    SET_STDOUT_MODE;\n\n')
    # Write code to start a do-loop.  The do-loop allows only a single function
    # return without the need for excessive indenting.
    c_file.write('    do\n')
    c_file.write('    {\n')
    # Write text to dump information if no program arguments are provided.
    # This code is written even if there are no positional arguments.
    c_file.write('        {0} If there are no arguments supplied then display the command to get help.{1}\n'.format(comment_start,
                                                                                                                    comment_end))
    c_file.write('        if (argc < 2)\n')
    c_file.write('        {\n')
    year_text = _get_year()
    if prog_properties.is_c_program():
        c_file.write('            _tprintf(_T("Program {0} [version 1.1 TODO:]{1}"));\n'.format(base_program_name, r'\n'))
        c_file.write('            _tprintf(_T("Copyright (C) {0} TODO:.{1}"));\n'.format(year_text, r'\n\n'))
        c_file.write('            _tprintf(_T("For help, enter:{0}"));\n'.format(r'\n\n'))
        c_file.write('            _tprintf(_T("    {0} -h{1}"));\n'.format(base_program_name, r'\n\n'))
    else:
        c_file.write('            STD_COUT << _T("Program {0} [version 1.1 TODO:]{1}");\n'.format(base_program_name, r'\n'))
        c_file.write('            STD_COUT << _T("Copyright (C) {0} TODO:.{1}");\n'.format(year_text, r'\n\n'))
        c_file.write('            STD_COUT << _T("For help, enter:{0}");\n'.format(r'\n\n'))
        c_file.write('            STD_COUT << _T("    {0} -h{1}");\n'.format(base_program_name, r'\n\n'))
    c_file.write('            break;\n')
    c_file.write('        }\n\n')
    if total_argument_count > 0:
        # Assign default values to the argument variables.
        # TypeName program_args.variableName = defaultValue;
        c_file.write('        {0} Initialize the program argument structure.{1}\n'.format(comment_start, comment_end))
        if prog_properties.is_cpp_program():
            c_file.write('        ProgramArgument_T program_args;\n')
        for arg_info in arg_info_list:
            default_value = arg_info.get_default_value()
            arg_type = arg_info.get_type()
            if arg_type == 'BOOL':
                default_value = convert_to_cpp_value(prog_properties, default_value)
            c_file.write('        program_args.{0} = {1};\n'.format(arg_info.get_name(),
                                                                    default_value))
        c_file.write('\n')
    # The program automatically accepts the -h switch and the --help switch,
    # so always add code to parse the arguments even if no switches are supplied.
    #if has_switch_argument(arg_info_list):
    if prog_properties.is_cpp_program():
        # Declare parsing variables.
        # Declare the argument options array.
        # static const ArgOption_t argument_option_array[] = <followed by declarations>
        c_file.write('        // Declare argument parsing variables.\n')
        leading_space_count = 8
        declare_argument_option_array(c_file, arg_info_list, leading_space_count)
        write_parsing_variable_declarations(c_file,
                                            arg_info_list,
                                            positional_argument_count,
                                            leading_space_count)
    c_file.write('        {0} Call the get_arguments function to populate the argument variables.{1}\n'.format(comment_start,
                                                                                                               comment_end))
    c_file.write('        while ((status == 0)\n')
    c_file.write('            && ((arg_result = get_arguments(argc,\n')
    c_file.write('                                            argv,\n')
    c_file.write('                                            &argument_option_array[0],\n')
    c_file.write('                                            &arg_index)) > ARG_NO_MORE_ARGUMENTS))\n')
    c_file.write('        {\n')
    c_file.write('            if (arg_result != ARG_POSITIONAL_ARGUMENT)\n')
    c_file.write('            {\n')
    c_file.write('                {0} Process an optional argument.{1}\n'.format(comment_start, comment_end))
    c_file.write('                switch (arg_result)\n')
    c_file.write('                {\n')
    out_of_band_count = 0
    for arg_info in arg_info_list:
        if arg_info.has_switch():
            # If there is a short switch, use that name.  Otherwise use an out-of-band character
            # with the long name switch.
            short_switch_name, long_switch_name = get_switch_names(arg_info.get_switch_name_list())
            if long_switch_name and not short_switch_name:
                c_file.write("                case OPTINT{0}:\n".format(out_of_band_count))
                out_of_band_count += 1
            else:
                c_file.write("                case '{0}':\n".format(short_switch_name))
            c_file.write('                    {\n')
            arg_type = arg_info.get_type()
            if arg_type == 'BOOL':
                bool_text = get_opposite_bool_text(arg_info.get_default_value())
                bool_text = convert_to_cpp_value(prog_properties, bool_text)
                c_file.write('                        program_args.{0} = {1};\n'.format(arg_info.get_name(), bool_text))
            elif arg_type == 'int':
                c_file.write('                        program_args.{0} = _tcstol(argv[arg_index], &stop_ptr, 10);\n'.format(arg_info.get_name()))
                write_conversion_validation_code(c_file, prog_properties)
            elif arg_type == 'float':
                c_file.write('                        program_args.{0} = (float)_tcstod(argv[arg_index], &stop_ptr);\n'.format(arg_info.get_name()))
                write_conversion_validation_code(c_file, prog_properties)
            elif arg_type == 'double':
                c_file.write('                        program_args.{0} = _tcstod(argv[arg_index], &stop_ptr);\n'.format(arg_info.get_name()))
                write_conversion_validation_code(c_file, prog_properties)
            else: # arg_type == 'string'
                c_file.write('                        program_args.{0} = argv[arg_index];\n'.format(arg_info.get_name()))
            c_file.write('                    }\n')
            c_file.write('                    break;\n\n')
    c_file.write("                case 'h':\n")
    c_file.write('                    {\n')
    c_file.write("                        displayUsage();\n")
    c_file.write('                        status = 1;\n')
    c_file.write('                    }\n')
    c_file.write('                    break;\n\n')
    c_file.write('                default:\n')
    c_file.write('                    {\n')
    c_file.write('                        {0} It should be impossible to reach here.{1}\n'.format(comment_start, comment_end))
    if prog_properties.is_c_program():
        c_file.write('                        _tprintf(_T("Program error.  Contact support.{0}"));\n'.format(r'\n'))
    else:
        c_file.write('                        STD_COUT << _T("Program error.  Contact support.{0}");\n'.format(r'\n'))
    c_file.write('                        status = 1;\n')
    c_file.write('                    }\n')
    c_file.write('                    break;\n')
    c_file.write('                }\n')
    c_file.write('            }\n')
    # Write code to save the positional arguments.
    if has_positional_argument(arg_info_list):
        c_file.write('            else\n')
        c_file.write('            {\n')
        c_file.write('                {0} Process a positional argument.{1}\n'.format(comment_start, comment_end))
        c_file.write('                switch (positional_arg_index)\n')
        c_file.write('                {\n')
        positional_index = 0
        for arg_info in arg_info_list:
            if arg_info.is_positional():
                c_file.write('                case {0}:\n'.format(positional_index))
                c_file.write('                    {\n')
                arg_type = arg_info.get_type()
                if arg_type == 'BOOL':
                    bool_text = get_opposite_bool_text(arg_info.get_default_value())
                    bool_text = convert_to_cpp_value(prog_properties, bool_text)
                    c_file.write('                        program_args.{0} = {1};\n'.format(arg_info.get_name(),
                                                                                            bool_text))
                elif arg_type == 'int':
                    c_file.write('                        program_args.{0} = _tcstol(argv[arg_index], &stop_ptr, 10);\n'.format(arg_info.get_name()))
                    write_conversion_validation_code(c_file, prog_properties)
                elif arg_type == 'float':
                    c_file.write('                        program_args.{0} = (float)_tcstod(argv[arg_index], &stop_ptr);\n'.format(arg_info.get_name()))
                    write_conversion_validation_code(c_file, prog_properties)
                elif arg_type == 'double':
                    c_file.write('                        program_args.{0} = _tcstod(argv[arg_index], &stop_ptr);\n'.format(arg_info.get_name()))
                    write_conversion_validation_code(c_file, prog_properties)
                else: # arg_type == 'string'
                    c_file.write('                        program_args.{0} = argv[arg_index];\n'.format(arg_info.get_name()))

                c_file.write('                    }\n')
                c_file.write('                    break;\n\n')
                positional_index += 1
        c_file.write('                default:\n')
        c_file.write('                   {\n')
        if prog_properties.is_c_program():
            c_file.write('                        _tprintf(_T("Too many positional arguments atarting at %s.{0}"), argv[arg_index]);\n'.format(r'\n'))
        else:
            c_file.write('                        STD_COUT << _T("Too many positional arguments atarting at %s.{0}") << argv[arg_index] << _T("{1}");\n'.format(r'\n', r'\n'))
        c_file.write('                        status = -1;\n')
        c_file.write('                         break;\n')
        c_file.write('                   }\n')
        c_file.write('                }\n\n')
        c_file.write('                {0} Increment the positional argument index.{1}\n'.format(comment_start, comment_end))
        c_file.write('                ++positional_arg_index;\n')
        c_file.write('            }\n')
    # End of while loop.
    c_file.write('        }\n\n')
    # Write code to check for an errors.
    c_file.write('        {0} Check for a command line error.{1}\n'.format(comment_start, comment_end))
    c_file.write('        if (status != 0)\n')
    c_file.write('        {\n')
    c_file.write('            break;\n')
    c_file.write('        }\n')
    c_file.write('        else if (arg_result == ARG_ERROR_MISSING_SWITCH_ARGUMENT)\n')
    c_file.write('        {\n')
    if prog_properties.is_c_program():
        c_file.write('            _tprintf(_T("Error - missing switch argument for switch %s.{0}"), argv[arg_index]);\n'.format(r'\n'))
    else:
        c_file.write('            STD_COUT << _T("Error - missing switch argument for switch %s.{0}") << argv[arg_index] << _T("{1}");\n'.format(r'\n', r'\n'))
    c_file.write('            status = -1;\n')
    c_file.write('            break;\n')
    c_file.write('        }\n')
    c_file.write('        else if (arg_result == ARG_ERROR_INVALID_SWITCH)\n')
    c_file.write('        {\n')
    if prog_properties.is_c_program():
        c_file.write('            _tprintf(_T("Invalid switch argument %s.{0}"), argv[arg_index]);\n'.format(r'\n'))
    else:
        c_file.write('            STD_COUT << _T("Invalid switch argument %s.{0}") << argv[arg_index] << _T("{1}");\n'.format(r'\n', r'\n'))
    c_file.write('            status = -1;\n')
    c_file.write('            break;\n')
    c_file.write('        }\n')
    # Write code to ensure that the command line contained at
    # least the minimum number of required positional arguments.
    if has_positional_argument(arg_info_list):
        c_file.write('        {0} Were the required number of positional arguments supplied?{1}\n'.format(comment_start, comment_end))
        c_file.write('        else if (positional_arg_index < {0})\n'.format(required_positional_arg_count))
        c_file.write('        {\n')
        if prog_properties.is_c_program():
            c_file.write('            _tprintf(_T("Too few arguments.{0}"));\n'.format(r'\n'))
        else:
            c_file.write('            STD_COUT << _T("Too few arguments.{0}");\n'.format(r'\n'))
        c_file.write('            status = -1;\n'.format(r'\n'))
        c_file.write('            break;\n'.format(r'\n'))
        c_file.write('        }\n')
    # Write code to call the primary function.
    if total_argument_count > 0:
        c_file.write('        else\n')
        c_file.write('        {\n')
        c_file.write('            {0} Process the input data.{1}\n'.format(comment_start, comment_end))
        #primary_function_call = _get_function_call_string('',
        #                                                  primary_function_name,
        #                                                  primary_function_arg_info_list)
        #c_file.write('            status = {0}\n'.format(primary_function_call))
        c_file.write('            status = execute{0}(&program_args);\n'.format(base_program_name))
        c_file.write('        }\n')
    # End the do-loop.
    c_file.write('    }\n')
    if prog_properties.is_c_program():
        c_file.write('    while (FALSE);\n\n')
    else:
        c_file.write('    while (false);\n\n')
    c_file.write('    return status;\n')
    c_file.write('}\n\n')
    # End of writing the main program.
    if total_argument_count > 0:
        #---------------------------------------------------------------
        # Write the primary function.
        #---------------------------------------------------------------
        c_file.write('{0} Function: {1}{2}\n'.format(comment_start, primary_function_name, comment_end))
        c_file.write('{0}\n'.format(primary_function_declaration_text))
        c_file.write('{\n')
        c_file.write('    {0} Display the input parameters.{1}\n'.format(comment_start, comment_end))
        format_character_dict = { 'BOOL' : 'd', 'int' : 'd', 'float' : 'f', 'double' : 'f', 'TCHAR *' : 's' }
        for arg_info in arg_info_list:
            arg_type = arg_info.get_type()
            format_character = format_character_dict[arg_type]
            # _tprintf("%s = %d", name,  program_args_ptr->name);
            if prog_properties.is_c_program():
                c_file.write('    _tprintf(_T("{0} {1} = %{2}{3}"), program_args_ptr->{4});\n'.format(arg_type,
                                                                                                      arg_info.get_name(),
                                                                                                      format_character,
                                                                                                      r'\n',
                                                                                                      arg_info.get_name()))
            else:
                c_file.write('    STD_COUT << _T("{0} {1}") << program_args_ptr->{2} << _T("{3}");\n'.format(arg_type,
                                                                                                             arg_info.get_name(),
                                                                                                             arg_info.get_name(),
                                                                                                             r'\n'))
        c_file.write('    return 0;\n')
        c_file.write('}\n\n')
    # End of writing the primary function.
    #-------------------------------------------------------------------
    # Write the function to display usage.
    #-------------------------------------------------------------------
    c_file.write('{0} Function: displayUsage{1}\n'.format(comment_start, comment_end))
    c_file.write('void displayUsage()\n')
    c_file.write('{\n')
    # _tprintf(_T("\n"));
    # _tprintf("_T("Program {0}\n")");
    # _tprintf(_T("Copyright (c) {0}, TODO:.\n\n"));
    # _tprintf(_T("This program TODO:.\n"));
    # _tprintf(_T("Usage:\n\n"));
    # _tprintf(_T("\n"));
    # _tprintf(_T("    {0}\n"));
    if prog_properties.is_c_program():
        c_file.write('    _tprintf(_T("{0}"));\n'.format(r'\n'))
        c_file.write('    _tprintf(_T("Program {0}{1}"));\n'.format(base_program_name, r'\n'))
        c_file.write('    _tprintf(_T("Copyright (c) {0}, TODO:.{1}"));\n'.format(_get_year(), r'\n\n'))
        c_file.write('    _tprintf(_T("This program TODO:.{0}"));\n'.format(r'\n\n'))
        c_file.write('    _tprintf(_T("Usage:{0}"));\n'.format(r'\n\n'))
    else:
        c_file.write('    STD_COUT << _T("{0}");\n'.format(r'\n'))
        c_file.write('    STD_COUT << _T("Program {0}{1}");\n'.format(base_program_name, r'\n'))
        c_file.write('    STD_COUT << _T("Copyright (c) {0}, TODO:.{1}");\n'.format(_get_year(), r'\n\n'))
        c_file.write('    STD_COUT << _T("This program TODO:.{0}");\n'.format(r'\n\n'))
        c_file.write('    STD_COUT << _T("Usage:{0}");\n'.format(r'\n\n'))
    program_argument_help_text = _get_program_argument_help_text(arg_info_list,
                                                                 required_positional_arg_count)
    if prog_properties.is_c_program():
        c_file.write('    _tprintf(_T("    {0}{1}{2}"));\n'.format(base_program_name,
                                                                   program_argument_help_text,
                                                                   r'\n\n'))
    else:
        c_file.write('    STD_COUT << _T("    {0}{1}{2}");\n'.format(base_program_name,
                                                                     program_argument_help_text,
                                                                     r'\n\n'))
    if has_positional_argument(arg_info_list):
        if prog_properties.is_c_program():
            c_file.write('    _tprintf(_T("Positional arguments:{0}"));\n'.format(r'\n\n'))
        else:
            c_file.write('    STD_COUT << _T("Positional arguments:{0}");\n'.format(r'\n\n'))
        for arg_info in arg_info_list:
            if arg_info.is_positional():
                if prog_properties.is_c_program():
                    # _tprintf(_T("{0}         {1} argument that TODO:\n"))
                    c_file.write('    _tprintf(_T("{0}       {1} argument that TODO:{2}"));\n'.format(arg_info.get_name(),
                                                                                                      arg_info.get_type_name(),
                                                                                                      r'\n'))
                else:
                    c_file.write('    STD_COUT << _T("{0}       {1} argument that TODO:{2}");\n'.format(arg_info.get_name(),
                                                                                                        arg_info.get_type_name(),
                                                                                                        r'\n'))
    if has_switch_argument(arg_info_list):
        if prog_properties.is_c_program():
            c_file.write('    _tprintf(_T("{0}Optional arguments:{1}"));\n'.format(r'\n', r'\n\n'))
        else:
            c_file.write('    STD_COUT << _T("{0}Optional arguments:{1}");\n'.format(r'\n', r'\n\n'))
        for arg_info in arg_info_list:
            if arg_info.has_switch():
                space_name = ''
                if arg_info.get_type() != 'BOOL':
                    space_name = ' {0}'.format(arg_info.get_name())
                short_switch_name, long_switch_name = get_switch_names(arg_info.get_switch_name_list())
                if short_switch_name:
                    short_switch_name = '-{0}{1}'.format(short_switch_name, space_name)
                if long_switch_name:
                    if short_switch_name:
                        long_switch_name = ', --{0}{1}'.format(long_switch_name, space_name)
                    else:
                        long_switch_name = '--{0}{1}'.format(long_switch_name, space_name)
                # _tprintf(_T("-n name, --name name        TODO:\n"));
                combined_switch_name = '{0}{1}'.format(short_switch_name, long_switch_name)
                if arg_info.get_type() == 'BOOL':
                    bool_text = get_opposite_bool_text(arg_info.get_default_value())
                    if prog_properties.is_c_program():
                        c_file.write('    _tprintf(_T("{0}        If specified, {1} becomes {2} TODO:{3}"));\n'.format(combined_switch_name,
                                                                                                                       arg_info.get_name(),
                                                                                                                       bool_text,
                                                                                                                       r'\n'))
                    else:
                        bool_text = convert_to_cpp_value(prog_properties, bool_text)
                        c_file.write('    STD_COUT << _T("{0}        If specified, {1} becomes {2} TODO:{3}");\n'.format(combined_switch_name,
                                                                                                                         arg_info.get_name(),
                                                                                                                         bool_text,
                                                                                                                         r'\n'))
                else:
                    if prog_properties.is_c_program():
                        c_file.write('    _tprintf(_T("{0}        {1} parameter {2} TODO:{3}"));\n'.format(combined_switch_name,
                                                                                                           arg_info.get_type_name(),
                                                                                                           arg_info.get_name(),
                                                                                                           r'\n'))
                    else:
                        c_file.write('    STD_COUT << _T("{0}        {1} parameter {2} TODO:{3}");\n'.format(combined_switch_name,
                                                                                                             arg_info.get_type_name(),
                                                                                                             arg_info.get_name(),
                                                                                                             r'\n'))
    if prog_properties.is_c_program():
        c_file.write('    _tprintf(_T("-h, --help      Display program help.{0}"));\n'.format(r'\n\n'))
    else:
        c_file.write('    STD_COUT << _T("-h, --help      Display program help.{0}");\n'.format(r'\n\n'))
    c_file.write('}\n')
    print 'Created main program file "{0}".'.format(c_file_name)
