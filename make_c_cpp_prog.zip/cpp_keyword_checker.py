#!/usr/bin/env python
#=======================================================================
# Copyright (C) 2013 William Hallahan
#
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation
# files (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
# WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
# OTHER DEALINGS IN THE SOFTWARE.
#=======================================================================

class CppKeywordChecker:
    """ Class to check whether a string is a C++ keyword. """

    def __init__(self):
        """ Initialize the class instance. """
        # Because C-language programs can be converted to C++ programs,
        # exclude C++ keywords in the C program.
        # For C++ 11, "override" and "final" have special meanings in some
        # contexts, but can be used in the name of functions and objects,
        # and so these words are not included in the list below.
        self.cpp_keyword_list = ['alignas', 'alignof', 'and', 'and_eq', 'asm',
                                 'auto', 'bitand', 'bitor', 'bool', 'break',
                                 'case', 'catch', 'char', 'char16_t', 'char32_t',
                                 'class', 'compl', 'const', 'constexpr',
                                 'const_cast', 'continue', 'decltype', 'default',
                                 'delete', 'do', 'double', 'dynamic_cast',
                                 'else', 'enum', 'explicit', 'export', 'extern',
                                 'false', 'float', 'for', 'friend', 'goto',
                                 'if', 'inline', 'int', 'long', 'mutable',
                                 'namespace', 'new', 'noexcept', 'not', 'not_eq',
                                 'nullptr', 'operator', 'or', 'or_eq', 'private',
                                 'protected', 'public', 'register',
                                 'reinterpret_cast', 'return', 'short', 'signed',
                                 'sizeof', 'static', 'static_assert',
                                 'static_cast', 'struct', 'switch', 'template',
                                 'this', 'thread_local', 'throw', 'true', 'try',
                                 'typedef', 'typeid', 'typename', 'union',
                                 'unsigned', 'using', 'virtual', 'void',
                                 'volatile', 'wchar_t', 'while', 'xor', 'xor_eq']

    def is_cpp_keyword(self, name):
        """ Return True if and only if the name is a C++ keyword. """
        return name in self.cpp_keyword_list
