#!/usr/bin/env python
#=======================================================================
# Copyright (C) 2013 William Hallahan
#
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation
# files (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
# WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
# OTHER DEALINGS IN THE SOFTWARE.
#=======================================================================

from program_properties import ProgramProperties

class MakefileCreator:

    C_LANGUAGE = 0
    CPP_LANGUAGE = 1

    def __init__(self, prog_properties):
        self.prog_properties = prog_properties
        self.compiler_name = 'gcc'
        self.source_file_extension = 'c'
        self.source_file_list = []

    def set_language(self, language):
        if language == MakefileCreator.C_LANGUAGE:
            self.compiler_name = 'gcc'
            self.source_file_extension = '.c'
        elif language == MakefileCreator.CPP_LANGUAGE:
            self.compiler_name = 'g++'
            self.source_file_extension = '.cpp'
        else:
            raise ValueError('Unknown programming language.')

    def add_source_file(self, file_name):
        self.source_file_list.append(file_name)

    def create_makefile(self):
        """ Creates a Makefile. """
        project_name = self.prog_properties.get_base_name()
        compiler_name = 'gcc'
        source_file_extension = '.c'
        if self.prog_properties.is_cpp_program():
            compiler_name = 'g++'
            self.source_file_extension = self.prog_properties.get_file_extension()
        # Write the Makefile.
        make_file_name = 'Makefile'
        with open(make_file_name, 'w') as make_file:
            make_file.write('CC={0}\n'.format(compiler_name))
            make_file.write('CFLAGS=-c -Wall\n')
            make_file.write('LDFLAGS=\n')
            make_file.write('SOURCES={0}\n'.format(self._get_source_text()))
            make_file.write('OBJECTS=$(SOURCES:{0}=.o)\n'.format(source_file_extension))
            make_file.write('EXECUTABLE={0}\n\n'.format(project_name))
            make_file.write('all: $(SOURCES) $(EXECUTABLE)\n	\n')
            make_file.write('$(EXECUTABLE): $(OBJECTS) \n')
            make_file.write('	$(CC) $(LDFLAGS) $(OBJECTS) -o $@\n\n')
            make_file.write('{0}.o:\n'.format(source_file_extension))
            make_file.write('	$(CC) $(CFLAGS) $< -o $@\n\n')
            make_file.write('.PHONY: clean\n\n')
            make_file.write('clean:\n')
            make_file.write('	rm -f *.o\n')
            make_file.write('	rm -f {0}\n'.format(project_name))
            print 'Created file "Makefile".'

    def _get_source_text(self):
        source_text = ' '.join(self.source_file_list)
        return source_text