#!/usr/bin/env python
#=======================================================================
# Copyright (C) 2013 William Hallahan
#
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation
# files (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
# WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
# OTHER DEALINGS IN THE SOFTWARE.
#=======================================================================

import re

class CArgInfo:
    """ Instances of the CArgInfo class store argument properties. """

    name_regex = re.compile('[A-Za-z_]*[0-9A-Za-z_]')

    def __init__(self):
        self.name = ''
        self.default_value = ''
        self.data_type = ''
        self.switch_name_list = []
        self.default_value_dict = { 'TCHAR *' : '', 'BOOL' : 'FALSE', 'int' : '0',
                                    'float' : '0.0F', 'double' : '0.0' }
        self.type_name_dict = { 'TCHAR *' : 'String', 'BOOL' : 'Boolean', 'int' : 'Integer',
                                'float' : 'Floating point', 'double' : 'Double precision floating point' }

    def get_switch_name_list(self):
        return self.switch_name_list

    def set_switch_name_list(self, switch_name_list):
        # Up to two switches are allowed
        if len(switch_name_list) > 2:
            raise ValueError('Too many switches supplied, {0}'.format(switch_name_list))
        # Validate each switch name in the switch name list.
        # Legal combinations are:
        # One switch, a single dash followed by a single character.
        # One switch, two dashes followed by one or more characters.
        # Both a single character switch and a long name switch.
        if len(switch_name_list) > 2:
            raise ValueError('Too many switches supplied.\nThere can only a short switch, a long switch, or both.\n{0}'.format(switch_name_list))             
        short_switch_name_count = 0
        long_switch_name_count = 0
        for switch_name in switch_name_list:
            if switch_name.startswith('--'):
                long_switch_name_count += 1
            elif switch_name.startswith('-'):
                short_switch_name_count += 1
        if short_switch_name_count > 1:
            raise ValueError('There can only be a single short-name switch.\n{0}'.format(switch_name_list))
        if long_switch_name_count > 1:
            raise ValueError('There can only be a single long-name switch.\n{0}'.format(switch_name_list))
        self.switch_name_list = switch_name_list

    def has_switch(self):
        return len(self.switch_name_list) != 0

    def is_positional(self):
        return len(self.switch_name_list) == 0

    def get_name(self):
        return self.name

    def set_name(self, name):
        self.validate_name(name)
        self.name = name

    def get_default_value(self):
        """ Return a default value for inclusion in program code. """
        default_value = ''
        if self.default_value:
            default_value = self.default_value
        else:
            default_value = self.default_value_dict[self.get_type()]
        if self.get_type() == 'TCHAR *':
            if not default_value.startswith(r'"'):
                default_value = '"{0}'.format(default_value)
            if not default_value.endswith(r'"') or len(default_value) == 1:
                default_value = '{0}"'.format(default_value)
            default_value = '_T({0})'.format(default_value)
        return default_value
        
    def get_display_default_value(self):
        """ Return a default value string for display to the user. """
        default_value = ''
        if self.default_value:
            default_value = self.default_value
        else:
            default_value = self.default_value_dict[self.get_type()]
        return default_value

    def set_default_value(self, default_value):
        self.default_value = default_value

    def get_type(self):
        if not self.data_type:
            self.data_type = 'TCHAR *'
        return self.data_type

    def get_type_name(self):
        return self.type_name_dict[self.data_type]

    def set_type(self, data_type):
        self.data_type = data_type

    def validate_name(self, name):
        result = CArgInfo.name_regex.match(name)
        if not result:
            raise ValueError('Illegal name: {0}'.format(name))

def validate_no_duplicate_switches(arg_info_list):
    """ Throw an exception if there are any duplicate switch names. """
    switch_list = []
    for arg_info in arg_info_list:
        for switch_name in arg_info.get_switch_name_list():
            if switch_name in switch_list:
                raise ValueError('Duplicate switch name {0}.'.format(switch_name))
            switch_list.append(switch_name)

def has_non_bool_switch_argument(arg_info_list):
    """ Return whether there are any switch arguments
        that are not type 'BOOL'.
    """
    has_non_bool_switch_argument = False
    for arg_info in arg_info_list:
        switch_list = arg_info.get_switch_name_list()
        if len(switch_list) > 0 and arg_info.get_type() != 'BOOL':
            has_non_bool_switch_argument = True
            break
    return has_non_bool_switch_argument

def get_number_of_switch_arguments(arg_info_list):
    """ Calculate the number of switch arguments. """
    count = 0
    for arg_info in arg_info_list:
        switch_list = arg_info.get_switch_name_list()
        count = count + len(switch_list)
    return count

def has_switch_argument(arg_info_list):
    """ Determine if there are any switch arguments. """
    return get_number_of_switch_arguments(arg_info_list) > 0

def get_number_of_positional_arguments(arg_info_list):
    """ Calculate the number of non-switch arguments. """
    count = 0
    for arg_info in arg_info_list:
        switch_list = arg_info.get_switch_name_list()
        if len(switch_list) == 0:
            count = count + 1
    return count

def has_positional_argument(arg_info_list):
    """ Determine if there are any non-switch arguments. """
    return get_number_of_positional_arguments(arg_info_list) > 0

def has_int_parameter(arg_info_list):
    """ Check to see if there are any integer parameters. """
    has_int_param = False
    for arg_info in arg_info_list:
        if arg_info.get_type() == 'int':
            has_int_param = True
            break
    return has_int_param

def has_float_parameter(arg_info_list):
    """ Check to see if there are any floating point parameters. """
    has_float_param = False
    for arg_info in arg_info_list:
        the_type = arg_info.get_type()
        if the_type == 'float' or the_type == 'double':
            has_float_param = True
            break
    return has_float_param
