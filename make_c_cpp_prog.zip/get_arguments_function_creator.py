#!/usr/bin/env python
#=======================================================================
# Copyright (C) 2013 William Hallahan
#
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation
# files (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
# WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
# OTHER DEALINGS IN THE SOFTWARE.
#=======================================================================

def write_get_arguments_header_file():
    """ Write the get_arguments function header file. """
    get_arguments_header_text = """/* ********************************************************************
 * Header File: get_arguments.h
 * Author: Bill Hallahan
 * Date: September 26, 2013
 *
 * Copyright (C) 2013 William Hallahan
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge,
 * publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 ******************************************************************* */

#ifndef GET_ARGUMENTS_H
#define GET_ARGUMENTS_H

#include "platform_os.h"

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/* The get_arguments function either returns an option
 * character or one of these values. */
typedef enum
{
    ARG_ERROR_INVALID_SWITCH = -2,
    ARG_ERROR_MISSING_SWITCH_ARGUMENT = -1,
    ARG_NO_MORE_ARGUMENTS = 0,
    ARG_POSITIONAL_ARGUMENT = 0x7FFFFFFF
} ArgOptionChar_t;

/* Used to set whether an option requires a parameter. */
typedef enum
{
    OPTION_NO_PARAMETER,
    OPTION_REQUIRES_PARAMETER
} ArgOptionParameter_t;

/* The option structure. 
 * Element c stores the short option character, i.e. "b" for "-b".
 *   name is the long option name string, "build" for "--build".
 * requires_params is set to one of the ArgOptionParameter_t
 *   enum values to indicate whether the option requires a parameter. */
typedef struct
{
    int c;
    TCHAR * long_name;
    ArgOptionParameter_t requires_param;
} ArgOption_t;

 /* ********************************************************************
 * Function: get_arguments
 *
 * Abstract:
 *
 *  The get_arguments function was written to provide argument
 *  parsing code for multiple platforms.  Also, the code can
 *  be used under the terms of the MIT license.
 *
 *  The get_arguments function allows both short and long
 *  optional switches, and will work with the ASCII, UTF-8, and
 *  Unicode character sets.
 *
 *  Both single character and long optional argument switch
 *  named are allowed.
 *
 *  Optional arguments and positional arguments can be interspersed.
 *
 *  The benefit of allowing interspersed optional and positional
 *  arguments comes at the cost of requiring that an optional argument
 *  either does, or does not, take an additional parameter, but not both.
 *
 *  Also, optional argument names cannot start with a digit
 *  character.  This simplified parsing as a dash followed by
 *  a digit character could also be the start of a numeric
 *  positional argument.
 *
 *  Input:
 *
 *    The first two arguments are passed into the 'main' function of
 *    a C or C++ console program.
 *
 *    argc                      - The number of arguments.
 *
 *    argv                      - An array of pointers to argument strings.
 *
 *    argument_option_array_ptr - A pointer to an array of ArgOption_t
 *                                structures that specifies that attributes
 *                                of each optional argument.
 *
 *                                An example declaration for the array might be:
 *
 *                                static const ArgOption_t argument_option_array[] =
 *                                {
 *                                    { 'x', NULL, OPTION_NO_PARAMETER, },
 *                                    { 'f', NULL, OPTION_REQUIRES_PARAMETER, },
 *                                    { 'b', "build", OPTION_REQUIRES_PARAMETER, },
 *                                    { 'h', "help", OPTION_NO_PARAMETER, },
 *                                    {   0, NULL, OPTION_NO_PARAMETER }
 *                                };
 *
 *                                This would allow optional arguments of the form:
 *
 *                                -x
 *                                -f <somestring>
 *                                -b <somestring>
 *                                --build <somestring>
 *                                -h
 *                                --help
 *
 *                                A string must be supplied after the -s parameter
 *                                because OPTION_REQUIRES_PARAMETER is used.
 *                                
 *                                The final line must always be supplied as written
 *                                to terminate the data.
 *
 *                                Either a short argument name, a long
 *                                argument name, or both must be specified.
 *                                If only a long name is specified, the first
 *                                field of the ArgOption_t structure must be
 *                                set to an out-of-band integer value, which
 *                                for either ASCII or Unicode character sets
 *                                can be any value above 0x011FFFF.
 *                                 
 *
 *    arg_index_ptr               A pointer to an 'int' value that is used
 *                                to index into the argv[] array. The value
 *                                pointed to by arg_index_ptr specifies either
 *                                the index of a positional argument or the
 *                                index of the required parameter for an
 *                                optional argument that has the
 *                                OPTION_REQUIRES_PARAMETER attribute.
 *
 *  Returns:
 *
 *    An integer value that is either the option character for an
 *    optional argument, which is the first field in OptionsArg_t
 *    structure that matches the optional argument passed on the
 *    command line, or, one of the following values.
 *
 *    ARG_POSITIONAL_ARGUMENT  - Specified that argument in the argv
 *                               array, indexed by the index value
 *                               pointed to by arg_index_ptr, is a
 *                               positional argument.
 *
 *    ARG_NO_MORE_ARGUMENTS    - Specifies that there are no more
 *                               arguments to parse.
 *
 *    ARG_ERROR_INVALID_SWITCH - Invalid switch specified on the command
 *                               line.
 *
 *    ARG_ERROR_MISSING_SWITCH_ARGUMENT - A dash character for an
 *                                        optional argument was found
 *                                        but is missing required
 *                                        characters following the dash.
 *
 *  Any returned character value, represented as an integer, and
 *  the value of ARG_POSITIONAL_ARGUMENT, are always greater than
 *  zero.  ARG_NO_MORE_ARGUMENTS equals zero, and the error return
 *  values are negative numbers, so parsing should be done until
 *  the return value of this function is not greater than
 *  ARG_NO_MORE_ARGUMENTS, or zero.
 *
 ******************************************************************* */

int get_arguments(int argc,
                  TCHAR *argv[],
                  const ArgOption_t * argument_option_array_ptr,
                  int * arg_index_ptr);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* GET_ARGUMENTS_H */
"""
    get_argument_header_file_name = 'get_arguments.h'
    with open(get_argument_header_file_name, 'w') as outfile:
        outfile.write(get_arguments_header_text)
    print 'Created file "{0}".'.format(get_argument_header_file_name)
    return get_argument_header_file_name

def write_get_arguments_c_file():
    """ Write the get_arguments function c file. """
    get_arguments_function_text = r"""/* ********************************************************************
 * Header File: get_arguments.c
 * Author: Bill Hallahan
 * Date: September 26, 2013
 *
 * Copyright (C) 2013 William Hallahan
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge,
 * publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 ******************************************************************* */

#include "get_arguments.h"

int get_arguments(int argc,
                  TCHAR *argv[],
                  const ArgOption_t * argument_option_array_ptr,
                  int * arg_index_ptr)
{
    int arg_length = 0;
    int option_param_type = OPTION_NO_PARAMETER;
    const ArgOption_t * arg_option_ptr = argument_option_array_ptr;
    TCHAR * argument_ptr = NULL;
    int option_character = ARG_NO_MORE_ARGUMENTS;

    /* Increment the index to point to the next argument.
     * On the first call to this function, this increment
     * skips the program name. */
    ++(*arg_index_ptr);

    /* Are there more arguments? */
    if (*arg_index_ptr < argc)
    {
        /* There are more arguments.  Get the current argument string
         * and the number of characters in the argument string. */
        argument_ptr = argv[*arg_index_ptr];
        arg_length = _tcslen(argument_ptr);

        /* Check for the dash character.  The dash character starts either
         * an optional argument or a number. */
        if (argument_ptr[0] == _T('-'))
        {
            /* Optional arguments always have at least one non-digit character
             * after the dash character. */
            if (arg_length > 1)
            {
                /* A dash followed by a digit, period, or a plus sign is not a
                 * valid switch name and is considered to be a negative number. */
                if ((_istdigit(argument_ptr[1]))
                    || (argument_ptr[1] == _T('.'))
                    || (argument_ptr[1] == _T('+')))
                {
                    option_character = ARG_POSITIONAL_ARGUMENT;
                }
                else
                {
                    /* This is an optional argument.  Long optional arguments
                     * start with two dash characters followed by at least one
                     * character.  Check for a second dash character. */
                    if ((arg_length > 2) && (argument_ptr[1] == _T('-')))
                    {
                        /* This is a long optional argument of the form "--name".
                         * Skip the second '_' character. */
                        argument_ptr += 2;

                        /* Search for the argument long name in the argument options array */
                        while (arg_option_ptr->c != _T('\0'))
                        {
                            if ((arg_option_ptr->long_name != NULL)
                                && (_tcscmp(arg_option_ptr->long_name, argument_ptr) == 0))
                            {
                                option_character = arg_option_ptr->c;
                                option_param_type = arg_option_ptr->requires_param;
                                break;
                            }

                            /* Point to the next ArgOption_t instance in the array. */
                            ++arg_option_ptr;
                        }
                    }
                    else
                    {
                        /* This is a short optional argument of the form "-n".
                         * Skip the '_' character. */
                        ++argument_ptr;

                        /* This is a short optional argument of the form "-n".
                         * Search for the argument character in the argument options array */
                        while (arg_option_ptr->c != _T('\0'))
                        {
                            if (argument_ptr[0] == arg_option_ptr->c)
                            {
                                option_character = arg_option_ptr->c;
                                option_param_type = arg_option_ptr->requires_param;
                                break;
                            }

                            /* Point to the next ArgOption_t instance in the array. */
                            ++arg_option_ptr;
                        }
                    }

                    /* Check to see if the argument option matched any ArgOption_t entry
                     * in the array pointed to by 'argument_option_array_ptr'. */
                    if (option_character != ARG_NO_MORE_ARGUMENTS)
                    {
                        /* An option switch was found.  Does the switch require an argument? */
                        if (option_param_type == OPTION_REQUIRES_PARAMETER)
                        {
                            /* Increment the index to point to the switch argument. */
                            ++(*arg_index_ptr);

                            if (*arg_index_ptr >= argc)
                            {
                                /* The option parameter is missing.  Return an error. */
                                --(*arg_index_ptr);
                                option_character = ARG_ERROR_MISSING_SWITCH_ARGUMENT;
                            }
                        }
                    }
                    else
                    {
                        /* No option matched.  Return an error. */
                        option_character = ARG_ERROR_INVALID_SWITCH;
                    }
                }        
            }
            /* A single dash character is not a valid argument. */
            else if (arg_length == 1)
            {
                option_character = ARG_ERROR_MISSING_SWITCH_ARGUMENT;
            }
            else
            {
                option_character = ARG_POSITIONAL_ARGUMENT;
            }
        }
        else
        {
            option_character = ARG_POSITIONAL_ARGUMENT;
        }
    }
    else
    {
        option_character = ARG_NO_MORE_ARGUMENTS;
    }

    return option_character;
}
"""
    get_argument_c_file_name = 'get_arguments.c'
    with open(get_argument_c_file_name, 'w') as outfile:
        outfile.write(get_arguments_function_text)
    print 'Created file "{0}".'.format(get_argument_c_file_name)
    return get_argument_c_file_name
