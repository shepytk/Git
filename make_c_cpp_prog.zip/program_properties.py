#!/usr/bin/env python
#=======================================================================
# Copyright (C) 2013 William Hallahan
#
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation
# files (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
# WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
# OTHER DEALINGS IN THE SOFTWARE.
#=======================================================================

class ProgramProperties:
    """ Instances of the ProgramProperties class store program properties. """

    PROGRAM_TYPE_C = 0
    PROGRAM_TYPE_CPP = 1

    def __init__(self, base_name, program_type):
        self.base_name = base_name 
        self.program_type = program_type
        self.file_extension = '.c'

    def get_file_extension(self):
        return self.file_extension

    def set_file_extension(self, file_extension):
        self.file_extension = file_extension

    def is_c_program(self):
        return self.program_type == ProgramProperties.PROGRAM_TYPE_C

    def is_cpp_program(self):
        return self.program_type == ProgramProperties.PROGRAM_TYPE_CPP

    def set_program_type(self, program_type):
        self.program_type = program_type

    def get_base_name(self):
        return self.base_name

    def get_file_name(self):
        file_name = '{0}{1}'.format(self.base_name, self.file_extension)
        return file_name
