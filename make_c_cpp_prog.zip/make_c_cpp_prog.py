#!/usr/bin/env python
#=======================================================================
# Copyright (C) 2013 William Hallahan
#
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation
# files (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
# WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
# OTHER DEALINGS IN THE SOFTWARE.
#=======================================================================
"""
    This program generates C or C++ programs that parse command-line
    arguments and displays the parsed values.  The purpose of this
    program is to save typing and allowing the rapid creation of
    programs that can be modified for some intended purpose.

    Arguments passed to this program specify the program name and
    strings that control the creation of internal variable names and
    argument parsing code in the generated code.

        python make_c_cpp_prog.py <program name> <parameter text>

Usage:

    See further below for example command lines.

    Command line format:

        python make_c_cpp_prog.py <program name> <parameter text>

    The formal specification for the program command line is in the form of:

      Below <x> indicates x is required and [y] indicates that y is optional.

        python make_c_cpp_prog.py <program_name> [parameter 1] [parameter 2} ... [parameter N] 

    Each parameter is a comma delimited list of the form:

        <variable_name[="initial_value"]>[,parameter_type][,parameter_switch][,parameter_switch]

    The parameter_type, parameter_count_token, and any parameter_switch specifier
    can be in any order.

            About variable_name

    The variable name must always be the first item specified for each
    parameter.  The variable name may only contain letters of the
    English alphabet or the underscore character.  The initial_value for
    a variable name should only be surrounded by double quote characters
    if the parameter type is a string, and even then the double quotes
    are only necessary if the inital_value string contains whitespace.
    
    The only valid initial values for a Boolean parameter are False and True.
    
    If a positional parameter has an initial specified on the command line,
    then that positional argument is not a required parameter and all
    subsequent positional arguments are also not required arguments.

            About parameter_type

    The parameter_type specifier can be one of the following characters.
    If no initial_value is specified for each of these types, the
    indicated initital value default is used.

        s - A string argument
        i - An integer argument
        f - A floating point argument
        d - A double-precision floating point argument
        b - A Boolean argument

    If the parameter_type is not specified, then the parameter_type defaults
    to 's', which indicates a string argument.

            About parameter_switch

    An initial dash character indicate a parameter_switch.  A single
    dash character indicates a short, or single character, switch name.
    Two initial dash characters specify a long-name switch.

    Both a short-name switch and a long-name switch can be specified.

    The '-h' and '--help' switches are implemented automatically and
    should not be specified as switch parameters.

            Additional information regarding Boolean parameters.

    A Boolean parameter, with parameter_type 'b', is typically used as
    an optional switch parameter.  Using the switch for a Boolean
    parameter in the generated program results in the variable name for
    the Boolean argument being set to the opposite of the initial_value,
    which for the default for a Boolean parameter, changes the variable
    from False to True.

    Example command lines:

        python make_c_cpp_prog.py foo.cpp alpha,i beta,f file_name gamma,-g,--gm,b

    This command line generates a program named 'foo.cpp' that takes
    an integer parameter named 'alpha', a floating point parameter 
    named 'beta', then a string parameter named file_name, and finally
    an optional parameter named 'gamma' that is a Boolean value that
    is only 'True' if either the '-g' switch or the '--gm' switch is
    specified.

        python make_c_cpp_prog.py foo file_name='foo.txt'

    This command line creates a program named 'foo.c'  that takes a
    single optional argument named 'file_name'.  If no argument is
    specified, then file_name will be the value 'foo.txt'.

        Created files.
        
    <program name>.c           - For C++, the file extension will
                                 be either ".cc" or ".cpp".

    platform_os.h              - A header file with platform and
                                 operating specific definitions.

    get_arguments.h            - The header file for the 'get_arguments'
                                 function.

    get_arguments.h            - The implementation file for the
                                 'get_arguments' function.

    <base program name>.sln    - A Visual Studio 2008 solution file.

    <base program name>.vcproj - A Visual Studio 2008 project file.
    
    Makefile                   - A Linux Makefile.
"""
import sys
import os
import re
from program_properties import ProgramProperties
from carginfo import CArgInfo
from carginfo import validate_no_duplicate_switches
from carginfo import has_non_bool_switch_argument
from carginfo import get_number_of_switch_arguments
from carginfo import has_switch_argument
from carginfo import get_number_of_positional_arguments
from carginfo import has_positional_argument
from carginfo import has_int_parameter
from carginfo import has_float_parameter
from cpp_keyword_checker import CppKeywordChecker
from platform_os_file_creator import write_platform_os_header_file
from get_arguments_function_creator import write_get_arguments_header_file
from get_arguments_function_creator import write_get_arguments_c_file
from c_cpp_program_creator import write_c_cpp_program
from makefile_creator import MakefileCreator
from vs_build_file_creator import VisualStudioBuildFileCreator

def is_integer(s):
    """ Returns True if and only if the passed string specifies
        an integer value.
    """
    try:
        x = int(s)
        is_int = True
    except ValueError:
        is_int = False
    return is_int

def is_floating_point(s):
    """ Returns True if and only if the passed string specifies
        a floating point value.
    """
    try:
        x = float(s)
        is_float = True
    except ValueError:
        is_float = False
    return is_float

def opposite_boolean_string(value):
    result = 'FALSE'
    if value == 'FALSE':
        result = 'TRUE'
    return result

def get_argument_assignment(arg_type):
    right_hand_side = 'argv[index]'
    if arg_type == 'BOOL':
        right_hand_side = 'TRUE'
    elif arg_type == 'int':
        right_hand_side = '_tstoi(argv[index])'
    elif arg_type == 'float':
        right_hand_side = '(float)(_tstof(argv[index]))'
    elif arg_type == 'double':
        right_hand_side = '_tstof(argv[index])'
    return right_hand_side

def create_folder_under_current_directory(folder_name):
    current_path = os.getcwd()
    new_path = os.path.join(current_path, folder_name)
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)
    return new_path

def create_c_cpp_program_files(prog_properties,
                               arg_info_list,
                               platform_os_header_file_name,
                               required_positional_arg_count):
    with open(prog_properties.get_file_name(), 'w') as c_file:
        write_c_cpp_program(c_file,
                            prog_properties,
                            platform_os_header_file_name,
                            arg_info_list,
                            required_positional_arg_count)

def execute_make_c_cpp_prog(prog_properties,
                            arg_info_list,
                            required_positional_arg_count):
    """ Create a main program file, and build files for both Windows and Linux. """
    # Create a 'base_program_name' folder.
    base_program_name = prog_properties.get_base_name()
    new_path = create_folder_under_current_directory(base_program_name)
    # Change the current working directory to the new folder.
    os.chdir(new_path)
    # Create the platform and operating system header file.
    platform_os_header_file_name = write_platform_os_header_file(prog_properties)
    # Create the C language program file.
    create_c_cpp_program_files(prog_properties,
                               arg_info_list,
                               platform_os_header_file_name,
                               required_positional_arg_count)
    # Write file get_argument.c.
    get_argument_c_file_name = write_get_arguments_c_file()
    # Write file get_argument.h.
    get_argument_header_file_name = write_get_arguments_header_file()
    # Create a Visual Studio solution file.
    c_file_name = prog_properties.get_file_name()
    vs_build_creator = VisualStudioBuildFileCreator(base_program_name)
    vs_build_creator.add_source_file_name(c_file_name)
    vs_build_creator.add_source_file_name(get_argument_c_file_name)
    vs_build_creator.add_header_file_name(platform_os_header_file_name)
    vs_build_creator.add_header_file_name(get_argument_header_file_name)
    vs_build_creator.create_solution_file()
    # Create a Visual Studio project file.
    vs_build_creator.create_project_file()
    # Create a Linux Makefile.
    make_file_creator = MakefileCreator(prog_properties)
    make_file_creator.add_source_file(c_file_name)
    make_file_creator.add_source_file(get_argument_c_file_name)
    make_file_creator.create_makefile();
    return 0

def file_exists(file_name):
    """ Return True if and only if the file exists. """
    exists = True
    try:
        with open(file_name) as f:
            pass
    except IOError as io_error:
        exists = False
    return exists

def validate_arg_default_value(arg_type, arg_default_value, argument):
    """ Validate the argument default value based on the argument type. """
    # An empty argument type defaults to type 'TCHAR *'.
    if not arg_type or arg_type == 'TCHAR *':
        if not arg_default_value:
            arg_default_value = ''
    # If the parameter is a Boolean parameter, then the default
    # value must be either the string value 'FALSE' or 'TRUE'.
    elif arg_type == 'BOOL':
        if arg_default_value:
            if arg_default_value != 'FALSE' and arg_default_value != 'TRUE':
                raise ValueError("Boolean default value {0} in {1} must be either 'FALSE' or 'TRUE'".format(arg_default_value, argument))
        else:
            arg_default_value = 'FALSE'
    elif arg_type == 'int':
        if arg_default_value and not is_integer(arg_default_value):
            raise ValueError('Integer default value {0} in {1} is not a valid number.'.format(arg_default_value, argument))
        else:
            arg_default_value = '0'
    elif arg_type == 'float':
        if arg_default_value and not is_floating_point(arg_default_value):
            raise ValueError('Floating point default value {0} in {1} is not a valid floating point number.'.format(arg_default_value, argument))
        else:
            arg_default_value = '0.0F'
    else: # arg_type == 'double':
        if arg_default_value and not is_floating_point(arg_default_value):
            raise ValueError('Double precision floating point default value {0} in {1} is not a valid floating point number.'.format(arg_default_value, argument))
        else:
            arg_default_value = '0.0'
    return arg_default_value

def validate_variable_name(arg_name, cpp_keyword_checker, unique_name_list):
    """ Validate the variable name. """
    # Ensure the variable name is not a C++ keyword.
    if cpp_keyword_checker.is_cpp_keyword(arg_name):
        raise ValueError('Variable name "{0}" is a C++ keyword.'.format(arg_name))
    # Ensure the variable name is unique.
    if arg_name in unique_name_list:
        raise ValueError('Variable name "{0}" was already specified.'.format(arg_name))
    unique_name_list.append(arg_name)

# Start of main program.
def main(argv=None):
    if argv == None:
	    argv = sys.argv
    # Set the default return value to indicate success.
    status = 0
    # There must be at least one argument that is the program name.
    if len(argv) < 2:
        print 'Program: make_c_cpp_prog.py\nUse -h or --help for more information.'
        return status
    # Get the program name or  "-h" or "--help".
    base_program_name = argv[1]
    if base_program_name == '-h' or base_program_name == '--help':
        print __doc__
        return status
    program_name = base_program_name
    # Validate that the program name contains only valid characters.
    name_regex = re.compile(r'^[A-Za-z_][\.0-9A-Za-z_]*$')
    result = name_regex.match(program_name)
    if not result or (program_name != result.group()):
        raise ValueError('Illegal program name: {0}'.format(program_name))
    # Make sure the base program name does not have an extension.
    # If the extension is '.cc' or '.cpp' then create a C++ program,
    # otherwise create a C program.
    file_extension = '.c'
    program_type = ProgramProperties.PROGRAM_TYPE_C
    if base_program_name.endswith('.c'):
        base_program_name = base_program_name[:-2]
    elif base_program_name.endswith('.cc'):
        file_extension = '.cc'
        base_program_name = base_program_name[:-3]
        program_type = ProgramProperties.PROGRAM_TYPE_CPP
    elif base_program_name.endswith('.cpp'):
        file_extension = '.cpp'
        base_program_name = base_program_name[:-4]
        program_type = ProgramProperties.PROGRAM_TYPE_CPP
    prog_properties = ProgramProperties(base_program_name, program_type)
    prog_properties.set_file_extension(file_extension)
    # Make sure the base program name is a valid program name.
    param_info = CArgInfo()
    try:
        param_info.validate_name(base_program_name)
        # Add the file extension '.c'.
        program_name = '{0}.c'.format(base_program_name)
        # The argument list to this program can start with an optional argument
        # switch, followed by the argument name followed by the type of the argument,
        # each separated by a comma character.  The argument type must be one of the
        # following: 's' for TCHAR *, 'b' for bool, 'i' for int, 'f' for float, or
        # 'd' for double.
        positional_arg_default_value_specified = False
        required_positional_arg_count = 0
        arg_type_dict = {'s' : 'TCHAR *', 'b' : 'BOOL', 'i' : 'int', 'f' : 'float', 'd' : 'double'}
        unique_name_list = []
        param_info_list = []
        cpp_keyword_checker = CppKeywordChecker()
        for i in xrange(2, len(argv)):
            # Get the current argument string.
            argument = argv[i].strip()
            arg_item_list = argument.split(',')
            # Create a new CArgInfo instance to store the argument settings.
            param_info = CArgInfo()
            # Get the argument name and remove it from the list.
            arg_name = arg_item_list.pop(0)
            # Check for a default value for the argument name.
            arg_default_value = ''
            arg_name_list = arg_name.split('=')
            if len(arg_name_list) > 1:
                arg_name = arg_name_list[0]
                arg_default_value = arg_name_list[1]
            # Declare optional argument setting variables.
            arg_switch_list = []
            arg_type = ''
            # Loop and parse any optional comma-delimited parameters.
            for arg_item in arg_item_list:
                # Does the parameter specify an argument switch?
                if arg_item.startswith('-'):
                    arg_switch_list.append(arg_item)
                    continue
                # Does the parameter specify an argument type?
                elif (len(arg_item) == 1 and arg_item in 'sbifd'):
                    # Was an argument type already found?
                    if arg_type:
                        raise ValueError('Argument type {1} in {0} is a duplicate type.'.format(arg_item, argument))
                    # Look up the argument type token.
                    arg_type = arg_type_dict.get(arg_item)
                    continue
                # The input is invalid.
                raise ValueError('Parameter {0} contains invalid setting {1}.'.format(argument, arg_item))
            # If any positional (non-switch) argument has a default value supplied, then that
            # argument is not a required argument, and all subsequent positional arguments are
            # also not required arguments, whether a default argument is supplied or not.
            if len(arg_switch_list) == 0:
                if arg_default_value:
                    positional_arg_default_value_specified = True
                if not positional_arg_default_value_specified:
                    required_positional_arg_count = required_positional_arg_count + 1
            # Validate the argument default value and the variable name.
            arg_default_value = validate_arg_default_value(arg_type, arg_default_value, argument)
            validate_variable_name(arg_name, cpp_keyword_checker, unique_name_list)
            # Save the argument parameters.
            param_info.set_name(arg_name)
            param_info.set_default_value(arg_default_value)
            param_info.set_switch_name_list(arg_switch_list)
            param_info.set_type(arg_type)
            # Add the argument info to the list of arguments.
            param_info_list.append(param_info)
        # Raise an exception if there is a duplicate argument switch.
        validate_no_duplicate_switches(param_info_list)
        # If the output file already exists, then prompt the user to overwrite the file.
        if file_exists(program_name):
            print "File '{0}' already exists. Enter 'y' or 'Y' to overwrite the file. >".format(program_name),
            c = raw_input()
            if c != 'y' and c != 'Y':
                return status
        # Open the program file and write the program.
        execute_make_c_cpp_prog(prog_properties,
                                param_info_list,
                                required_positional_arg_count)
    except EnvironmentError as environment_error:
        print environment_error
        status = -1
    except ValueError as value_error:
        print value_error
        status = -1
    return status

if __name__ == "__main__":
    sys.exit(main())
