#!/usr/bin/env python
#=======================================================================
# Copyright (C) 2013 William Hallahan
#
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation
# files (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
# WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
# OTHER DEALINGS IN THE SOFTWARE.
#=======================================================================
"""
    write a platform header file that allows the generated C program
    to run on multiple platforms.
"""
from program_properties import ProgramProperties

def write_platform_os_header_file(prog_properties):
    """ Write a header file that contains platform-specific definitions. """
    # Write the program includes and type definitions in the form:
    #
    # #ifndef PLATFORM_OS_H
    # #define PLATFORM_OS_H
    #
    # #include <stddef.h>
    #
    # #ifdef WIN32
    # #include <tchar.h>
    #
    # #ifdef UNICODE
    # #ifdef WIN32
    # #ifdef UNICODE
    # #include <io.h>
    # #include <fcntl.h>
    # #define ENABLE_IO_MODE  _setmode(_fileno(stdout), _O_U16TEXT)
    # #endif /* UNICODE */
    # #endif /* WIN32 */
    #
    # #ifdef __linux__
    # typedef char TCHAR;
    #
    # #define _T(X) X
    # define ENABLE_IO_MODE
    # Definitions for Linux go here.
    # #endif // __linux__
    #
    # #endif // PLATFORM_OS_H
    platform_os_header_base_name = 'platform_os'
    conditional_compile_name = '{0}_H'.format(platform_os_header_base_name.upper())
    platform_os_header_file_name = '{0}.h'.format(platform_os_header_base_name)
    with open(platform_os_header_file_name, 'w') as platform_file:
        platform_os_header_file_header = """/* ********************************************************************
 * Header File: platform_os.h
 * Author: Bill Hallahan
 * Date: September 26, 2013
 *
 * Platform and operating system specific definitions.
 *
 * Copyright (C) 2013 William Hallahan
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge,
 * publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 ******************************************************************* */"""
        platform_file.write('{0}\n\n'.format(platform_os_header_file_header))
        platform_file.write('#ifndef {0}\n'.format(conditional_compile_name))
        platform_file.write('#define {0}\n\n'.format(conditional_compile_name))
        # Include a header file that defines 'NULL' for Linux.
        if prog_properties.is_cpp_program():
            platform_file.write('// On Windows, including <cstdef> causes a compile error, so <stddef.h> is used.\n\n')
        platform_file.write('//')        
        platform_file.write('#include <stddef.h>\n\n')
        platform_file.write('#ifdef WIN32\n')
        platform_file.write('#include <tchar.h>\n')
        platform_file.write('#ifdef UNICODE\n')
        platform_file.write('#include <wctype.h>\n')
        if prog_properties.is_cpp_program():
            platform_file.write('#include <io.h>\n')
            platform_file.write('#include <fcntl.h>\n\n')
            platform_file.write('#define SET_STDOUT_MODE  _setmode(_fileno(stdout), _O_U16TEXT)\n')
            platform_file.write('#define STD_COUT std::wcout\n')
        # Start of non-UNICODE definitions.
        platform_file.write('#else  /* Not UNICODE */\n')
        platform_file.write('#include <ctype.h>\n')
        if prog_properties.is_cpp_program():
            platform_file.write('\n')
            platform_file.write('#define SET_STDOUT_MODE\n')
            platform_file.write('#define STD_COUT std::cout\n')
        platform_file.write('#endif /* UNICODE */\n')
        platform_file.write('#endif /* WIN32 */\n\n')
        platform_file.write('#ifdef __linux__\n')
        platform_file.write('#include <ctype.h>\n')
        if prog_properties.is_c_program():
            platform_file.write('#include <stddef.h>\n')
            platform_file.write('#include <string.h>\n')
        else:
            platform_file.write('#include <cstddef>\n')
            platform_file.write('#include <cstring>\n')
        platform_file.write('\n')
        platform_file.write('typedef char TCHAR;\n\n')
        platform_file.write('#define SET_STDOUT_MODE\n')
        platform_file.write('#define STD_COUT std::cout\n')
        platform_file.write('#define _T(X) X\n')
        platform_file.write('#define _tmain main\n')
        platform_file.write('#define _tprintf printf\n')
        platform_file.write('#define _istdigit isdigit\n')
        platform_file.write('#define _tcslen strlen\n')
        platform_file.write('#define _tcscmp strcmp\n')
        platform_file.write('#define _tcstol strtol\n')
        platform_file.write('#define _tcstod strtod\n')
        platform_file.write('#endif /* __linux__ */\n\n')
        if prog_properties.is_c_program():
            platform_file.write('#define FALSE (0)\n')
            platform_file.write('#define TRUE (1)\n\n')
            platform_file.write('typedef int BOOL;\n\n')
        platform_file.write('#endif /* {0} */\n'.format(conditional_compile_name))
        print 'Created include file "{0}".'.format(platform_os_header_file_name)
        return platform_os_header_file_name
